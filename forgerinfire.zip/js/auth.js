
// DOM Elements
const form = document.getElementById('auth-form');
const nameGroup = document.getElementById('name-group');
const pageTitle = document.getElementById('page-title');
const pageSubtitle = document.getElementById('page-subtitle');
const submitBtn = document.getElementById('submit-btn');
const switchBtn = document.getElementById('switch-btn');
const switchText = document.getElementById('switch-text');

// State
let isLogin = true;

// Check query params for mode
const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('mode') === 'register') {
    toggleMode();
}

// Event Listeners
switchBtn.addEventListener('click', toggleMode);
form.addEventListener('submit', handleAuth);

function toggleMode() {
    isLogin = !isLogin;

    if (isLogin) {
        nameGroup.style.display = 'none';
        pageTitle.textContent = 'Welcome Back';
        pageSubtitle.textContent = 'Enter your details to access your account.';
        submitBtn.textContent = 'Sign In';
        switchText.textContent = "Don't have an account?";
        switchBtn.textContent = 'Create one';
    } else {
        nameGroup.style.display = 'block';
        // Add slide down animation for name group
        nameGroup.style.animation = 'fadeIn 0.3s ease';
        pageTitle.textContent = 'Create Account';
        pageSubtitle.textContent = 'Start your journey to greatness today.';
        submitBtn.textContent = 'Get Started';
        switchText.textContent = 'Already have an account?';
        switchBtn.textContent = 'Sign In';
    }
}

function handleAuth(e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const name = document.getElementById('name').value;

    // Simple validation
    if (!email || !password || (!isLogin && !name)) {
        alert('Please fill in all fields');
        return;
    }

    // Simulate API call
    submitBtn.textContent = 'Processing...';
    submitBtn.disabled = true;

    setTimeout(() => {
        const user = {
            id: 'usr_' + Math.random().toString(36).substr(2, 9),
            email,
            name: isLogin ? 'User' : name,
            joinedDate: new Date().toISOString()
        };

        // Save to local storage
        localStorage.setItem('goalforge_user', JSON.stringify(user));
        localStorage.setItem('goalforge_token', 'mock_jwt_token_' + Date.now());

        // Redirect logic
        if (isLogin) {
            window.location.href = '/pages/dashboard.html';
        } else {
            window.location.href = '/pages/onboarding.html';
        }
    }, 1000);
}
