
// Access user data
const user = JSON.parse(localStorage.getItem('goalforge_user')) || { name: 'User' };
document.getElementById('greeting').innerText = `Good Morning, ${user.name}`;
