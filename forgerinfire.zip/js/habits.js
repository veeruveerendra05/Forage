
// Mock data
let habits = [
    { id: 1, name: "Morning Run", category: "fitness", streak: 12, completed: 65, color: "#10b981", icon: "🏃" },
    { id: 2, name: "LeetCode Daily", category: "coding", streak: 45, completed: 100, color: "#8b5cf6", icon: "💻" },
    { id: 3, name: "Read 20 pages", category: "reading", streak: 5, completed: 30, color: "#ec4899", icon: "📚" },
    { id: 4, name: "Study Chemistry", category: "academics", streak: 8, completed: 50, color: "#f59e0b", icon: "🧪" },
    { id: 5, name: "News & GK", category: "knowledge", streak: 21, completed: 90, color: "#3b82f6", icon: "📰" }
];

const container = document.getElementById('habits-container');
const modal = document.getElementById('create-modal');

// Init
renderHabits('all');

// Global scope
window.filterHabits = (cat) => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    event.target.classList.add('active');
    renderHabits(cat);
};

window.openModal = () => modal.classList.add('active');
window.closeModal = () => modal.classList.remove('active');

document.getElementById('create-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('habit-name').value;
    const category = document.getElementById('habit-category').value;

    const icons = { fitness: '💪', coding: '💻', reading: '📚', academics: '🎓', knowledge: '🧠' };
    const colors = { fitness: '#10b981', coding: '#8b5cf6', reading: '#ec4899', academics: '#f59e0b', knowledge: '#3b82f6' };

    const newHabit = {
        id: Date.now(),
        name,
        category,
        streak: 0,
        completed: 0,
        color: colors[category],
        icon: icons[category]
    };

    habits.push(newHabit);
    renderHabits('all'); // Reset filter to show all
    closeModal();
    e.target.reset();
});

function renderHabits(filter) {
    container.innerHTML = '';

    const filtered = filter === 'all' ? habits : habits.filter(h => h.category === filter);

    filtered.forEach(h => {
        const card = document.createElement('div');
        card.className = 'habit-card';
        card.innerHTML = `
      <div class="priority-indicator" style="background: ${h.color}"></div>
      <div class="habit-header">
        <div class="habit-icon" style="background: ${h.color}20; color: ${h.color}">${h.icon}</div>
        <div style="text-align: right;">
          <div style="font-weight: 700; font-size: 1.25rem;">${h.streak}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Streak</div>
        </div>
      </div>
      <h3>${h.name}</h3>
      <div style="color: var(--text-dim); font-size: 0.875rem; text-transform: capitalize; margin-bottom: 1rem;">${h.category}</div>
      
      <div class="flex justify-between items-center" style="font-size: 0.875rem;">
        <span>Today's Goal</span>
        <span>${h.completed}%</span>
      </div>
      <div class="habit-progress-bar">
        <div class="habit-fill" style="width: ${h.completed}%; background: ${h.color};"></div>
      </div>
      
      <button class="btn w-full hover:brightness-110" style="margin-top: var(--space-lg); background: ${h.color}20; color: ${h.color};" onclick="checkIn(${h.id})">
        ${h.completed >= 100 ? 'Completed' : 'Check In'}
      </button>
    `;
        container.appendChild(card);
    });
}

window.checkIn = (id) => {
    const h = habits.find(x => x.id === id);
    if (h.completed < 100) {
        h.completed = Math.min(100, h.completed + 20); // increment by 20%
        if (h.completed === 100) h.streak++;
        renderHabits(document.querySelector('.filter-btn.active').innerText.toLowerCase() === 'all' ? 'all' : document.querySelector('.filter-btn.active').innerText.toLowerCase());
    }
};
